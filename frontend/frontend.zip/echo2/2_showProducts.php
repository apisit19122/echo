<?php
require_once("config/connect.config.php");
@session_start();
@error_reporting(E_ALL ^ E_NOTICE);

$sqlproduct = "SELECT * FROM product Where id = '" . $_GET['id'] . "'";
$resultproduct = mysqli_query($conn, $sqlproduct);
$dataproduct = mysqli_fetch_array($resultproduct);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="team" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->

    <!-- fortawesome -->
    <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@5.11.2/css/all.min.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/tooplate-style.css">
    <title>Show Products</title>

    <style>
        .Nav li {
            display: inline;
            margin-left: 5px;
            color: #0e1118;
        }

        .Nav li a:hover {
            display: inline;
            margin-left: 5px;
            color: #1a1f29;
        }

        .Nav {
            margin-top: 10px;
        }

        .hr {
            border: 1px solid #ccc;
            margin-bottom: 15px;
        }

        .Border-bg {
            margin: auto;
            margin-top: 50px;
            padding: 15px;

        }

        .showimages img {
            width: 30%;
            float: left;

        }

        .continue-shoppings {
            text-align: center;
            text-transform: uppercase;
            padding: 0.625rem 0;
            width: 40%;
            background-color: #0e1118;
            border: none;
            border-radius: 20px;
            padding: 10px;
            color: #fff;
        }

        .continue-shoppings:hover {
            background-color: #FF997E;
            border: none;
        }

        .continue-shoppings i {
            margin-right: 5px;
        }

        .share span {
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .share i {
            font-size: 18px;
            margin-left: 5px;
        }

        .share p {
            font-weight: 700;
            color: #0e1118;
            letter-spacing: 2px;
        }

        .details-products h5 {
            font-weight: 700;
        }

        .related-product h5 {
            font-weight: 700;
        }

        @media screen and (max-width: 767px) {
            .img-responsives {
                width: 300px;
                margin-left: 0px;
            }


            .continue-shoppings {
                display: block;
                text-align: center;
                text-transform: uppercase;
                padding: 0.625rem 0;
                width: 100%;
                background-color: #0e1118;
                border: none;
                border-radius: 20px;
                padding: 10px;
                color: #fff;
                margin-bottom: 10px;
            }
        }
    </style>
</head>

<body style="background-color: #fff;">


    <div class="container Border-bg">
        <div class="row">
            <div class="col-md-12 Nav">
                <ul>
                    <li><a href="#">Home |</a></li>
                    <li><a href="#">All products |</a></li>
                    <li><a href="#"><?php echo $dataproduct['name']; ?></a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5 Image">
                <div class="team-thumb">
                    <img src="<?php echo $dataproduct['photo']; ?>" class="img-responsives itemImg">
                </div>
                <div class="team-thumb showimages gallery">
                    <img src="<?php echo $dataproduct['photo1']; ?>" draggable="false" alt="Shoe Front" />
                    <img src="<?php echo $dataproduct['photo2']; ?>" draggable="false" alt="Shoe Back" />
                </div>
            </div>
            <div class="col-md-7 contant">
                <h3 style="font-weight: 700; letter-spacing: 3px;"><?php echo $dataproduct['name']; ?></h3>
                <div class="hr"></div>
                <small>Important ingredient :</small>
                <p><?php echo $dataproduct['detail']; ?>
                </p>
                <p style="font-size: 12px; color: #0e1118; text-align: right; font-weight: 600;">
                    No.22 BOYS’ TALK
                </p>
                <div style="margin: 20px;" class="share">
                    <p><?php echo $dataproduct['price']; ?></p>
                </div>
                <div style="margin: 20px;" class="share">
                    <span style="font-weight: 700;">Share</span>
                    <span>
                        <a href="/"><i class="fab fa-facebook-square" style="color: #4267B2;"></i></a></span>
                    <span>
                        <a href="/"><i class="fab fa-line" style="color: #00B900;"></i></a>
                    </span>
                    <span>
                        <a href="/"><i class="fab fa-instagram" style="color: #DA2778;"></i></a>
                    </span>
                </div>
                <div style="margin: 20px;" class="share">
                    <span style="font-weight: 700;">Categories :</span>
                    <span>medicine</span>
                </div>
                <a href="3_pay_test.php?id=<?= $dataproduct['id']; ?>&act=add"><button type="button" class="continue-shoppings" id="buttonCheckout" style="font-size: 13px;">
                        <i class="fas fa-cart-plus"></i>
                        Add to Cart
                    </button></a>
            </div>
        </div>
        <hr>


        <!-- Details Products -->
        <div class="details-products">
            <h5>Products Description</h5>
        </div>

        <hr>

        <!-- Products List -->
        <div class="related-product">
            <h5>Related Product</h5>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <img src="images/t4.jpg" class="img-responsive" alt="Andrew Orange">
                    <div class="pricing-thumb">
                        <div class="pricing-title">
                            <h4 style="text-align: center; font-weight: 600;">Echo Vitaoxxy FP</h4>
                        </div>
                        <div class="pricing-info">
                            <p>50 Responsive Designs</p>
                        </div>
                        <div class="pricing-bottom">
                            <p class="pricing-dollar">$350/mo</p>
                            <a href="#" class="section-btn pricing-btn">Buy</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <img src="images/t3.jpg" class="img-responsive" alt="Andrew Orange">
                    <div class="pricing-thumb">
                        <div class="pricing-title">
                            <h4 style="text-align: center; font-weight: 600;">Echo Collysine</h4>
                        </div>
                        <div class="pricing-info">
                            <p>50 Responsive Designs</p>
                        </div>
                        <div class="pricing-bottom">
                            <p class="pricing-dollar">$350/mo</p>
                            <a href="#" class="section-btn pricing-btn">Buy</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <img src="images/t2.jpg" class="img-responsive" alt="Andrew Orange">
                    <div class="pricing-thumb">
                        <div class="pricing-title">
                            <h4 style="text-align: center; font-weight: 600;">Echo Cal-bilberry</h4>
                        </div>
                        <div class="pricing-info">
                            <p>100 Responsive Designs</p>
                        </div>
                        <div class="pricing-bottom">
                            <p class="pricing-dollar">$550/mo</p>
                            <a href="#" class="section-btn pricing-btn">Buy</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <img src="images/t1.jpg" class="img-responsive" alt="Andrew Orange">
                    <div class="pricing-thumb">
                        <div class="pricing-title">
                            <h4 style="text-align: center; font-weight: 600;">Echo Riciomeg</h4>
                        </div>
                        <div class="pricing-info">
                            <p>100 Responsive Designs</p>
                        </div>
                        <div class="pricing-bottom">
                            <p class="pricing-dollar">$550/mo</p>
                            <a href="#" class="section-btn pricing-btn">Buy</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>


    <!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="jquery-3.5.1.min.js"></script>
    <script>
        $(function() {
            $('.gallery img').click(function() {
                $('.itemImg').attr('src', $(this).attr('src'));
            });
        })
    </script>
    
    <!-- SCRIPTS -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>