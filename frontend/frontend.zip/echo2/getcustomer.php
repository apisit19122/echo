
<?php 
require_once("config/connect.config.php");
 
	$bid =$_REQUEST["bid"];
	
 	$sql2= "SELECT * FROM  tb_model WHERE bid = '$bid' "; 
	
 	$result2 = mysqli_query($conn, $sql2); 
	
	while($row2 = mysqli_fetch_array($result2)) { 
	
	echo"<option value='$row[0]'>" .$row["price"]." </option>";
	}
 ?>