<!DOCTYPE html>
<html lang="en">

<?php
require_once("config/connect.config.php");
date_default_timezone_set('Asia/Bangkok');
@session_start();
//@error_reporting (E_ALL ^ E_NOTICE);

$c_id = $_SESSION['c_id'];
$or_id = $_SESSION['or_id'];

$sql4 = "SELECT * FROM namewebsite";
$rs4 = mysqli_query($conn, $sql4);
$data4 = mysqli_fetch_array($rs4);

$sql3 = "SELECT order_detail.id, order_detail.productID, order_detail.unit_price, 
        order_detail.unittotal_price, orders.createdAt, order_detail.customerID, order_detail.orderID,
        order_detail.orderID, orders.total_price, orders.ship_price, orders.status, orders.runnumber, 
        customer.cus_name, customer.cus_phone, customer.cus_address, customer.cus_email
        FROM order_detail
            INNER JOIN orders ON (order_detail.orderID = orders.id) 
            INNER JOIN customer ON (order_detail.customerID = customer.id) 
            INNER JOIN product ON (order_detail.productID = product.id) 
        WHERE order_detail.orderID ='" . $_GET['id'] . "'";
$rs3 = mysqli_query($conn, $sql3);
$data3 = mysqli_fetch_array($rs3);
?>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $data4['nw_name']; ?></title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico" />
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Gallery Lightbox -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <!-- Skills Circle CSS  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/circlebars@1.0.3/dist/circle.css">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Google Fonts Raleway -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,400i,500,500i,600,700" rel="stylesheet">
    <!-- Google Fonts Open sans -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,800" rel="stylesheet">


</head>

<body>

    <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- END SCROLL TOP BUTTON -->

    <!-- Start Header -->

    <!-- End Header -->

    <!-- End Page Header area -->
    <?php require_once 'navbar.php'; ?>
    <!-- Start Breadcrumb -->
    <div id="mu-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb" role="navigation">
                        <ol class="breadcrumb mu-breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start main content -->
    <main>

        <!-- End About -->

        <!-- End Skills -->

        <!-- Start Team -->
        <section id="mu-team">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-team-area">
                            <!-- Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mu-title">
                                        <h2>Invoice</h2>
                                        <p></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Main content -->
                            <div class="invoice p-3 mb-3">
                                <!-- title row -->
                                <div class="row">
                                    <div class="col-12">
                                        <h4>
                                            <i class="fas fa-globe"></i> <?php echo $data4['nw_name']; ?>
                                            <small class="float-right">Date/Time : <?php echo $data3['createdAt']; ?></small>
                                        </h4>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- info row -->
                                <div class="row invoice-info">
                                    <div class="col-sm-4 invoice-col">
                                        From
                                        <address>
                                            <strong><?php echo $data4['nw_name']; ?></strong><br>
                                            <?php echo $data4['address']; ?><br>
                                            Phone: <?php echo $data4['tel']; ?><br>
                                            Email: <?php echo $data4['email']; ?>
                                        </address>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-sm-4 invoice-col">
                                        To
                                        <address>
                                            <strong><?php echo $data3['cus_name']; ?></strong><br>
                                            Address: <?php echo $data3['cus_address']; ?><br>
                                            Phone: <?php echo $data3['cus_phone']; ?><br>
                                            Email: <?php echo $data3['cus_email']; ?>
                                        </address>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-sm-4 invoice-col">
                                        <b>Invoice #<?php echo $data3['orderID']; ?></b><br>
                                        <b>Order ID: <?php echo $data3['runnumber']; ?></b><br>
                                        <b>Payment Status:</b> <?php echo $data3['orderID']; ?><br>

                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->

                                <!-- Table row -->
                                <div class="row">
                                    <div class="col-12 table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Product image</th>
                                                    <th>Product ID</th>
                                                    <th>Product</th>
                                                    <th>Price</th>
                                                    <th>Amount</th>
                                                    <th>Subtotal</th>
                                                </tr>
                                            </thead>

                                            <?php
                                            $sql5 = "SELECT order_detail.productID, order_detail.unit_price, order_detail.unit,
                                                    order_detail.unittotal_price, product.name, product.product_id, product.price, product.photo
                                                    FROM order_detail
                                                        INNER JOIN orders ON (order_detail.orderID = orders.id) 
                                                        INNER JOIN customer ON (order_detail.customerID = customer.id) 
                                                        INNER JOIN product ON (order_detail.productID = product.id) 
                                                    WHERE order_detail.orderID ='$or_id'";
                                            $rs5 = mysqli_query($conn, $sql5);
                                            while ($data5 = mysqli_fetch_array($rs5)) {
                                            ?>
                                                <tbody>
                                                    <tr>
                                                        <td><img src="<?= $data5['photo']; ?>" style="width: 3rem;"> </td>
                                                        <td><?php echo $data5['product_id']; ?></td>
                                                        <td><?php echo $data5['name']; ?></td>
                                                        <td><?php echo $data5['price']; ?></td>
                                                        <td><?php echo $data5['unit']; ?></td>
                                                        <td><?php echo number_format($data5['unittotal_price'], 2); ?>.-</td>

                                                    </tr>

                                                </tbody>

                                            <?php } ?>

                                        </table>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->

                                <div class="row">
                                    <!-- accepted payments column -->
                                    <div class="col-6">
                                       <!--  <p class="lead">Payment Methods:</p>
                                        <img src="bank_img/b1.png" style="width: 2rem;"> เลขบัญชี: 000-0-00000-0 ชื่อ: Lisa <br> -->

                                    </div>
                                    <!-- /.col -->
                                    <div class="col-6">

                                        <div class="table-responsive">
                                            <table class="table">
                                                <tr>
                                                    <?php
                                                    $ordersno_totalprice1 = $data3['total_price'];
                                                    $ordersno_shipping1 = $data3['ship_price'];
                                                    $total1 =  $ordersno_totalprice1 - $ordersno_shipping1;

                                                    ?>
                                                    <th style="width:50%">Subtotal:</th>
                                                    <td><?php echo number_format($total1, 2); ?>.- Baht</td>
                                                </tr>
                                                <tr>
                                                    <th>Shipping:</th>
                                                    <td><?php echo number_format($data3['ship_price'], 2); ?>.- Baht</td>
                                                </tr>
                                                <tr>
                                                    <th>Total:</th>
                                                    <?php
                                                    $ordersno_totalprice = $data3['total_price'];
                                                    $ordersno_shipping = $data3['ship_price'];
                                                    $total =  $ordersno_totalprice + $ordersno_shipping;

                                                    ?>
                                                    <td><?php echo number_format($total, 2); ?>.- Baht</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->

                                <!-- this row will not appear when printing -->
                                <div class="row no-print">
                                    <div class="col-12">
                                        <a href="7_invoice-print.php?id=<?= $data3['orderID']; ?>" target="_blank" class="btn btn-success"> พิมพ์</a>
                                        <?php
                                        if ($data3['status'] == 1) {
                                        ?>
                                            <a href="8_payment.php?id=<?= $data3['orderID']; ?>" target="_blank" class="btn btn-success float-right"> แจ้งชำระเงิน</a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            <!-- /.invoice -->

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Team -->

        < </main> <!-- End main content -->


            <!-- JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
            <!-- Slick slider -->
            <script type="text/javascript" src="assets/js/slick.min.js"></script>
            <!-- Progress Bar -->
            <script src="https://unpkg.com/circlebars@1.0.3/dist/circle.js"></script>
            <!-- Filterable Gallery js -->
            <script type="text/javascript" src="assets/js/jquery.filterizr.min.js"></script>
            <!-- Gallery Lightbox -->
            <script type="text/javascript" src="assets/js/jquery.magnific-popup.min.js"></script>
            <!-- Counter js -->
            <script type="text/javascript" src="assets/js/counter.js"></script>
            <!-- Ajax contact form  -->
            <script type="text/javascript" src="assets/js/app.js"></script>


            <!-- Custom js -->
            <script type="text/javascript" src="assets/js/custom.js"></script>

            <!-- About us Skills Circle progress  -->
            <script>
                // First circle
                new Circlebar({
                    element: "#circle-1",
                    type: "progress",
                    maxValue: "90"
                });

                // Second circle
                new Circlebar({
                    element: "#circle-2",
                    type: "progress",
                    maxValue: "84"
                });

                // Third circle
                new Circlebar({
                    element: "#circle-3",
                    type: "progress",
                    maxValue: "60"
                });

                // Fourth circle
                new Circlebar({
                    element: "#circle-4",
                    type: "progress",
                    maxValue: "74"
                });
            </script>

</body>

</html>