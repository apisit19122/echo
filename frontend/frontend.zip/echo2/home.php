<?php
require_once("config/connect.config.php");

// @error_reporting(E_ALL ^ E_NOTICE);

function table()
{
     echo '';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

     <title>Echo health</title>
     <!--

    Template 2106 Soft Landing

	http://www.tooplate.com/view/2106-soft-landing

    -->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="team" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->

     <!-- fa -->
     <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@5.11.2/css/all.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/tooplate-style.css">

</head>

<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>

          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">echo</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                         <li><a href="#home" class="smoothScroll">Home</a></li>
                         <li><a href="#feature" class="smoothScroll">About us</a></li>
                         <li><a href="#about" class="smoothScroll">Products</a></li>
                         <li><a href="#pricing" class="smoothScroll">Ordering</a></li>
                         <li><a href="#contact" class="smoothScroll">Contact</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="#"><span>sevice@echohealthfood.com</span></a></li>
                    </ul>
               </div>

          </div>
     </section>


     <!-- FEATURE -->
     <section id="home" data-stellar-background-ratio="0.5">
          <div class="overlay"></div>
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-3 col-md-6 col-sm-12">
                         <div class="home-info">
                              <h3>Echo health co.,Ltd.</h3>
                              <h1>Echo health Extra life</h1>
                         </div>
                    </div>

               </div>
          </div>
     </section>


     <!-- FEATURE -->
     <section id="feature" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <img src=images/S__18309123.jpg class="img-responsives">
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-6">
                         <ul class="nav nav-tabs" role="tablist">
                              <li class="active"><a href="#tab01" aria-controls="tab01" role="tab" data-toggle="tab">About</a></li>

                              <li><a href="#tab02" aria-controls="tab02" role="tab" data-toggle="tab">Products</a></li>

                              <li><a href="#tab03" aria-controls="tab03" role="tab" data-toggle="tab">Support</a></li>
                         </ul>

                         <div class="tab-content">
                              <div class="tab-pane active" id="tab01" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <h2>About our company</h2>
                                        <p>Echo health co.,ltd was established in 2020. Our objectives are to develop
                                             dietary supplement, medical food and herbal medicine for serving to our
                                             priority customer. We intentionally focus on searching the best ingredients
                                             from natural source.</p>
                                   </div>
                              </div>

                              <div class="tab-pane" id="tab02" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <h2>Echo Cal-bilberry</h2>
                                        <p>Important ingredient : Calcium, Bilberry prevent osteoporosis
                                             increase bone mass anti-oxidant, improve brain and eyes function.
                                        </p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Echo Vitaoxxy FP</h2>
                                        <p>Important ingredient : L-lysine,Oxxynea FP and other 16 vitamin
                                             Improve muscle mass and body improve brain function.
                                        </p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Echo Collysine</h2>
                                        <p>Important ingredient : fish collagen peptide, Lysine
                                             Improve collagen in skin layer, anti- oxidant, skin lightening.
                                        </p>
                                   </div>
                                   <div class="tab-pane-item">
                                        <h2>Echo Riciomeg</h2>
                                        <p>Important ingredient : Rice germ oil, Omega 3
                                             maintain blood circulation, control lipid profile
                                        </p>
                                   </div>
                              </div>

                              <div class="tab-pane" id="tab03" role="tabpanel">

                                   <div class="tab-pane-item">
                                        <h2>Contact</h2>
                                        <p>Echo health co.,Ltd. 214 Sirindhorn Rd., Bangplath, Bangplath, Bangkok 10700
                                        </p>
                                   </div>

                                   <div class="tab-pane-item">
                                        <p><i class="fab fa-line" style="font-size: 25px; margin-right: 20px; color: #00B900;"></i>
                                             <a href="#" style="color: #757575;">@echohealth</a>
                                        </p>
                                        <p><i class="fab fa-facebook-square" style="font-size: 25px; margin-right: 20px; color: #4267B2;"></i>
                                             <a href="#" style="color: #757575;">Echo health </a>
                                        </p>
                                        <p><i class="fab fa-instagram" style="font-size: 25px; margin-right: 20px; color: #DA2778;"></i>
                                             <a href="#" style="color: #757575;">Echohealththailand</a>
                                        </p>
                                        <p><i class="fas fa-phone-alt" style="font-size: 25px; margin-right: 20px; color: #DA2778;"></i>
                                             +66 655 099 888</p>
                                        <p><i class="fas fa-envelope" style="font-size: 25px; margin-right: 20px; color: #2396F3;"></i><a href="#" style="color: #757575;">service@echohealthfood.com</a></p>
                                   </div>
                              </div>
                         </div>

                    </div>

                    <div class="col-md-6 col-sm-6">
                         <div class="feature-image">
                              <img src="images/AllEchos.png" class="img-responsive" alt="Thin Laptop">
                         </div>
                    </div>

               </div>
          </div>
     </section>


     <!-- ABOUT -->
     <section id="about" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-3 col-md-6 col-sm-12">
                         <div class="section-title">
                              <h1>Products our company</h1>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb">
                              <img src="images/Riciomeg1.png" class="img-responsive" alt="Jack Wilson" style="background-color: #FFEE8A;">
                              <div class="team-info team-thumb-up">
                                   <h2>Echo Vitaoxxy FP</h2>
                                   <small>Important ingredient :</small>
                                   <p>L-lysine,Oxxynea FP and other 16 vitamin
                                        Improve muscle mass and body improve brain function.
                                   </p>
                              </div>
                         </div>
                    </div>


                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb">
                              <div class="team-info team-thumb-down">
                                   <h2>Echo Cal-bilberry</h2>
                                   <small>Important ingredient :</small>
                                   <p>Calcium, Bilberry prevent osteoporosis
                                        increase bone mass anti-oxidant, improve brain and eyes function.
                                   </p>
                              </div>
                              <img src="images/Cal-Bilberry1.png" class="img-responsive" alt="Catherine Soft" style="background-color: #8BCFB1;">
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb">
                              <img src="images/Vitaoxxy_0.png" class="img-responsive" alt="Andrew Orange" style="background-color: #FF997E;">
                              <div class="team-info team-thumb-up">
                                   <h2>Echo Riciomeg</h2>
                                   <small>Important ingredient :</small>
                                   <p>Rice germ oil, Omega 3
                                        maintain blood circulation, control lipid profile
                                   </p>
                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>


     <!-- TESTIMONIAL -->
     <section id="testimonial" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="testimonial-image"></div>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="testimonial-info">

                              <div class="section-title">
                                   <h1>What Products Say</h1>
                              </div>

                              <div class="owl-carousel owl-theme">
                                   <div class="item">
                                        <h3>L-lysine,Oxxynea FP and other 16 vitamin
                                             Improve muscle mass and body improve brain function.
                                        </h3>
                                        <div class="testimonial-item">
                                             <img src="images/Collysine.png" class="img-responsive" alt="Michael" style="background-color: #FFDCDA;">
                                             <h4>Echo Vitaoxxy FP</h4>
                                        </div>
                                   </div>

                                   <div class="item">
                                        <h3> fish collagen peptide, Lysine
                                             Improve collagen in skin layer, anti- oxidant, skin lightening.
                                        </h3>
                                        <div class="testimonial-item">
                                             <img src="images/Vitaoxxy_0.png" class="img-responsive" alt="Sofia" style="background-color: #FF997E;">
                                             <h4>Echo Collysine</h4>
                                        </div>
                                   </div>

                                   <div class="item">
                                        <h3> Calcium, Bilberry prevent osteoporosis
                                             increase bone mass anti-oxidant, improve brain and eyes function.
                                        </h3>
                                        <div class="testimonial-item">
                                             <img src="images/Cal-Bilberry1.png" class="img-responsive" alt="Monica" style="background-color: #8BCFB1;">
                                             <h4>Echo Cal-bilberry</h4>
                                        </div>
                                   </div>

                                   <div class="item">
                                        <h3> Rice germ oil, Omega 3
                                             maintain blood circulation, control lipid profile.</h3>
                                        <div class="testimonial-item">
                                             <img src="images/Riciomeg1.png" class="img-responsive" alt="Monica" style="background-color: #FFEE8A;">
                                             <h4>Echo Riciomeg</h4>
                                        </div>
                                   </div>
                              </div>

                         </div>
                    </div>

               </div>
          </div>
     </section>


     <!-- PRICING -->
     <section id="pricing" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>Ordering</h1>
                         </div>
                    </div>

                    <?php
                    $sql_product = "SELECT * FROM product";
                    $query_product = mysqli_query($conn, $sql_product);
                    while ($data_product = mysqli_fetch_array($query_product, MYSQLI_ASSOC)) {
                    ?>

                         <div class="col-md-3 col-sm-6">
                              <img src="<?= $data_product['photo']; ?>" class="img-responsive" alt="Andrew Orange">
                              <div class="pricing-thumb">
                                   <div class="pricing-title">
                                        <h4 style="text-align: center; font-weight: 600;"><?= $data_product['name']; ?></h4>
                                   </div>
                                   <div class="pricing-info">
                                        <p><?= $data_product['detail']; ?></p>
                                   </div>
                                   <div class="pricing-bottom">
                                        <p class="pricing-dollar"><?= $data_product['price']; ?></p>
                                        <a href="" class="section-btn pricing-btn">Buy</a>
                                   </div>
                              </div>
                         </div>
                    <?php
                    }
                    mysqli_close($conn);
                    ?>
               </div>
          </div>
     </section>


     <!-- CONTACT -->
     <section id="contact" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-1 col-md-10 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="section-title">
                                   <h1>Contact</h1>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <input type="text" class="form-control" placeholder="Full name" name="name" required>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <input type="email" class="form-control" placeholder="Email address" name="email" required>
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <input type="submit" class="form-control" name="send message" value="Send Message">
                              </div>
                              <div class="col-md-12 col-sm-12">
                                   <textarea class="form-control" rows="8" placeholder="Your message" name="message" required></textarea>
                              </div>
                         </form>
                    </div>

               </div>
          </div>
     </section>


     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="copyright-text col-md-12 col-sm-12">
                         <div class="col-md-6 col-sm-6">
                              <p>Copyright &copy; 2018 Company echohealthfood - Design: Tooplate</p>
                         </div>

                         <div class="col-md-6 col-sm-6">
                              <ul class="social-icon">
                                   <li><a href="https://web.facebook.com/echosupplement/" class="fab fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fab fa-line"></a></li>
                                   <li><a href="https://www.instagram.com/echohealththailand/" class="fab fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>

               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/jquery.stellar.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>

</html>