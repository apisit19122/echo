<?php
session_start();
@error_reporting(E_ALL ^ E_NOTICE);

require_once("config/connect.config.php");

$sqlproduct = "SELECT * FROM product Where id = '" . $_GET['id'] . "'";
$resultproduct = mysqli_query($conn, $sqlproduct);
$dataproduct = mysqli_fetch_array($resultproduct);

$id = $_REQUEST['id'];
$act = $_REQUEST['act'];
if ($act == 'add' && !empty($id)) {
    if (!isset($_SESSION['shopping_cart'])) {
        $_SESSION['shopping_cart'] = array();
    } else {
    }
    if (isset($_SESSION['shopping_cart'][$id])) {
        $_SESSION['shopping_cart'][$id]++;
    } else {
        $_SESSION['shopping_cart'][$id] = 1;
    }
}
if ($act == 'remove' && !empty($id))  //ยกเลิกการสั่งซื้อ
{
    unset($_SESSION['shopping_cart'][$id]);
}

if ($act == 'update') {
    $amount_array = $_POST['amount'];
    foreach ($amount_array as $id => $amount) {
        $_SESSION['shopping_cart'][$id] = $amount;
    }
}
//ยกเลิกสินค้าทั้งตะกร้า
if ($act == 'Cancel-Cart') {
    unset($_SESSION['shopping_cart']);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Basket</title>

    <!-- Style -->
    <link rel="stylesheet" href="css/cart.css">

    <!-- fortawesome -->
    <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@5.11.2/css/all.min.css">

</head>

<body>

    <main>
        <div class="basket">
            <p style="text-align: left; font-size: 25px; font-weight: 700; color: #0e1118;">Your Cart</p>
            <div class="basket-labels">
                <ul>
                    <li class="item item-heading">Item</li>
                    <li class="price">Price</li>
                    <li class="quantity">Quantity</li>
                    <li class="subtotal">Subtotal</li>
                </ul>
            </div>
            <?php
            /*$sql_product = "SELECT * FROM product";
                $query_product = mysqli_query($conn, $sql_product);
                while ($data_product = mysqli_fetch_array($query_product, MYSQLI_ASSOC)) {*/


            if (!empty($_SESSION['shopping_cart'])) {
                require_once("config/connect.config.php");
                foreach ($_SESSION['shopping_cart'] as $id => $p_qty) {
                    $sql = "select * from product where id =$id";
                    $query = mysqli_query($conn, $sql);
                    while ($row = mysqli_fetch_array($query)) {
            ?>

                        <div class="basket-product">
                            <div class="item">
                                <div class="product-image">
                                    <img src="<?php echo $row['photo']; ?>" alt="Placholder Image 2" class="product-frame">
                                </div>
                                <div class="product-details">
                                    <h1><strong><span class=""></span>x <?php echo $row['name']; ?></strong></h1>
                                    <p><?php echo $rowt['product_id']; ?></p>

                                </div>
                            </div>
                            <div class="price"><?php echo $row['price']; ?></div>
                            <div class="quantity">
                                <input type="number" value="0" min="1" class="quantity-field">

                            </div>

                            <div class="subtotal"></div>
                            <a href='3_pay.php?id=<?= $row['id']; ?>&act=remove' class='btnRemoveAction'><i class='fa fa-trash fa-lg'></i>Remove</a>
                            <!-- <div class="remove">
                                <button><i class="far fa-trash-alt"></i>Remove</button>
                            </div> -->

                        </div>
            <?php
                    }
                }
            }
            ?>
        </div>

        <aside>
            <div class="summary">
                <div class="summary-total-items"><span class="total-items"></span> Items in your Bag</div>
                <div class="summary-subtotal">
                    <div class="subtotal-title">Subtotal</div>
                    <div class="subtotal-value final-value" id="basket-subtotal"><?php echo $sum = $row['price'] * $q; ?></div>
                    <div class="summary-promo hide">
                        <div class="promo-title">Promotion</div>
                        <div class="promo-value final-value" id="basket-promo"></div>
                    </div>
                </div>
                <div class="summary-delivery">
                    <h4>Select shipping</h4>
                    <select name="delivery-collection" class="summary-delivery-selection">
                    <?php
                        $ship = "SELECT * FROM shippingCost";
                        $query_ship = mysqli_query($conn, $ship);
                        while ($data_ship = mysqli_fetch_array($query_ship, MYSQLI_ASSOC)) {
                        ?>
                            <option value=""><?= $data_ship['name']; ?>             <?= $data_ship['price']; ?> ฿</option>
                        <?php
                        }
                        ?>
                    </select>
                </div>

                <div class="summary-total">
                    <div class="total-title">Total</div>
                    <div class="total-value final-value" id="basket-total"><?php echo $total += $sum; ?></div>
                </div>
                <div class="summary-checkout">
                    <a href="1_home.php"><button type="button" class="continue-shopping" id="buttonCheckout" style="margin-bottom: 5px;">
                            <i class="fas fa-cart-plus"></i>
                            Continue Shopping
                        </button></a>
                    <a href="4_confirm.php"><button class="checkout-cta"><i class="fas fa-shopping-cart"></i>Go to Secure Checkout</button></a>
                </div>
            </div>
        </aside>
    </main>

    <!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="jquery-3.5.1.min.js"></script>
    <!-- <script src="js/cart.js"></script> -->

    <script>
        /* Set values + misc */
        var promoCode;
        var promoPrice;
        var fadeTime = 0;

        /* Assign actions */
        $('.quantity input').change(function() {
            updateQuantity(this);
        });

        $('.remove button').click(function() {
            removeItem(this);
        });

        $(document).ready(function() {
            updateSumItems();
        });

        $('.promo-code-cta').click(function() {

            promoCode = $('#promo-code').val();

            if (promoCode == '10off' || promoCode == '10OFF') {
                //If promoPrice has no value, set it as 10 for the 10OFF promocode
                if (!promoPrice) {
                    promoPrice = 10;
                } else if (promoCode) {
                    promoPrice = promoPrice * 1;
                }
            } else if (promoCode != '') {
                alert("Invalid Promo Code");
                promoPrice = 0;
            }
            //If there is a promoPrice that has been set (it means there is a valid promoCode input) show promo
            if (promoPrice) {
                $('.summary-promo').removeClass('hide');
                $('.promo-value').text(promoPrice.toFixed(2));
                recalculateCart(true);
            }
        });

        /* Recalculate cart */
        function recalculateCart(onlyTotal) {
            var subtotal = 0;

            /* Sum up row totals */
            $('.basket-product').each(function() {
                subtotal += parseFloat($(this).children('.subtotal').text());
            });

            /* Calculate totals */
            var total = subtotal;

            //If there is a valid promoCode, and subtotal < 10 subtract from total
            var promoPrice = parseFloat($('.promo-value').text());
            if (promoPrice) {
                if (subtotal >= 10) {
                    total -= promoPrice;
                } else {
                    alert('Order must be more than £10 for Promo code to apply.');
                    $('.summary-promo').addClass('hide');
                }
            }

            /*If switch for update only total, update only total display*/
            if (onlyTotal) {
                /* Update total display */
                $('.total-value').fadeOut(fadeTime, function() {
                    $('#basket-total').html(total.toFixed(2));
                    $('.total-value').fadeIn(fadeTime);
                });
            } else {
                /* Update summary display. */
                $('.final-value').fadeOut(fadeTime, function() {
                    $('#basket-subtotal').html(subtotal.toFixed(2));
                    $('#basket-total').html(total.toFixed(2));
                    if (total == 0) {
                        $('.checkout-cta').fadeOut(fadeTime);
                    } else {
                        $('.checkout-cta').fadeIn(fadeTime);
                    }
                    $('.final-value').fadeIn(fadeTime);
                });
            }
        }

        /* Update quantity */
        function updateQuantity(quantityInput) {
            /* Calculate line price */
            var productRow = $(quantityInput).parent().parent();
            var price = parseFloat(productRow.children('.price').text());
            var quantity = $(quantityInput).val();
            var linePrice = price * quantity;

            /* Update line price display and recalc cart totals */
            productRow.children('.subtotal').each(function() {
                $(this).fadeOut(fadeTime, function() {
                    $(this).text(linePrice.toFixed(2));
                    recalculateCart();
                    $(this).fadeIn(fadeTime);
                });
            });

            productRow.find('.item-quantity').text(quantity);
            updateSumItems();
        }

        function updateSumItems() {
            var sumItems = 0;
            $('.quantity input').each(function() {
                sumItems += parseInt($(this).val());
            });
            $('.total-items').text(sumItems);
        }

        /* Remove item from cart */
        function removeItem(removeButton) {
            /* Remove row from DOM and recalc cart total */
            var productRow = $(removeButton).parent().parent();
            productRow.slideUp(fadeTime, function() {
                productRow.remove();
                recalculateCart();
                updateSumItems();
            });
        }
    </script>
</body>





</html>