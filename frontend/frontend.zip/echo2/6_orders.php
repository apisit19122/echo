<!DOCTYPE html>
<html lang="en">

<?php
require_once("config/connect.config.php");
date_default_timezone_set('Asia/Bangkok');
@session_start();
//@error_reporting (E_ALL ^ E_NOTICE);
$c_id = $_SESSION['c_id'];
?>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>My order list</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico" />
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Gallery Lightbox -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <!-- Skills Circle CSS  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/circlebars@1.0.3/dist/circle.css">


    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Google Fonts Raleway -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,400i,500,500i,600,700" rel="stylesheet">
    <!-- Google Fonts Open sans -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,800" rel="stylesheet">


</head>

<body>

    <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- END SCROLL TOP BUTTON -->

    <!-- Start Header -->

    <!-- End Header -->

    <!-- End Page Header area -->
    <?php require_once 'navbar.php'; ?>
    <!-- Start Breadcrumb -->
    <div id="mu-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb" role="navigation">
                        <ol class="breadcrumb mu-breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->


    <!-- Start main content -->
    <main>

        <!-- End About -->


        <!-- End Skills -->

        <!-- Start Team -->
        <section id="mu-team">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-team-area">
                            <!-- Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mu-title">
                                        <h2>Order list</h2>
                                        <p></p>
                                    </div>
                                </div>
                            </div>

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Order Id</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Status</th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <?php
                                $sql = "SELECT orders.id, orders.customerID, orders.createdAt, orders.status,  
                                                orders.ship_price, payment_status.status_name
                                        FROM orders
                                        LEFT JOIN customer
                                            ON (orders.customerID = customer.id) 
                                        LEFT JOIN payment_status
                                            ON (orders.status = payment_status.id) 
                                        WHERE orders.customerID ='$c_id' ORDER BY customer.id DESC";
                                /* $sql = "SELECT *
                                        FROM orders AS t1 LEFT JOIN customer AS t2 ON (t1.customerID = t2.id) 
							            LEFT JOIN payment_status AS t3 ON (t1.status = t3.id) 
                                        WHERE customerID ='$c_id' ORDER BY t1.id DESC"; */
                                $rs = mysqli_query($conn, $sql);
                                while ($data = mysqli_fetch_array($rs)) {
                                ?>
                                    <tbody>
                                        <tr>
                                            <th scope="row">#<?php echo $data['id']; ?></th>
                                            <td><?php echo $data['createdAt']; ?></td>
                                            <td>
                                                <?php
                                                if ($data['status'] == 1) {
                                                ?>
                                                    <span class="badge badge-secondary"><?php echo $data['status_name']; ?></span>
                                                <?php } ?>
                                                <?php
                                                if ($data['status'] == 2) {
                                                ?>
                                                    <span class="badge badge-success"><?php echo $data['status_name']; ?></span>
                                                <?php } ?>
                                                <?php
                                                if ($data['status'] == 3) {
                                                ?>
                                                    <span class="badge badge-warning"><?php echo $data['status_name']; ?></span>
                                                <?php } ?>
                                                <?php
                                                if ($data['status'] == 4 || $data['status'] == 5) {
                                                ?>
                                                    <span class="badge badge-success"><?php echo $data['status_name']; ?></span>
                                                <?php } ?>

                                            </td>
                                            <td class="project-actions text-right" style="font-family: 'Mali', cursive;">
                                                <a class="btn btn-info btn-sm" href="7_invoice.php?id=<?=  $_SESSION['or_id'] = $data['id']; ?>">
                                                    Viwe
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                <?php } ?>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Team -->

        < </main> <!-- End main content -->


            <!-- Start footer -->
            <!-- <?php require_once 'footer_c.php'; ?> -->
            <!-- End footer -->

            <!-- JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
            <!-- Slick slider -->
            <script type="text/javascript" src="assets/js/slick.min.js"></script>
            <!-- Progress Bar -->
            <script src="https://unpkg.com/circlebars@1.0.3/dist/circle.js"></script>
            <!-- Filterable Gallery js -->
            <script type="text/javascript" src="assets/js/jquery.filterizr.min.js"></script>
            <!-- Gallery Lightbox -->
            <script type="text/javascript" src="assets/js/jquery.magnific-popup.min.js"></script>
            <!-- Counter js -->
            <script type="text/javascript" src="assets/js/counter.js"></script>
            <!-- Ajax contact form  -->
            <script type="text/javascript" src="assets/js/app.js"></script>


            <!-- Custom js -->
            <script type="text/javascript" src="assets/js/custom.js"></script>

            <!-- About us Skills Circle progress  -->
            <script>
                // First circle
                new Circlebar({
                    element: "#circle-1",
                    type: "progress",
                    maxValue: "90"
                });

                // Second circle
                new Circlebar({
                    element: "#circle-2",
                    type: "progress",
                    maxValue: "84"
                });

                // Third circle
                new Circlebar({
                    element: "#circle-3",
                    type: "progress",
                    maxValue: "60"
                });

                // Fourth circle
                new Circlebar({
                    element: "#circle-4",
                    type: "progress",
                    maxValue: "74"
                });
            </script>

</body>

</html>