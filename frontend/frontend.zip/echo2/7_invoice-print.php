<!DOCTYPE html>
<?php
require_once("config/connect.config.php");
date_default_timezone_set('Asia/Bangkok');
@session_start();
//@error_reporting (E_ALL ^ E_NOTICE);

$c_id = $_SESSION['c_id'];
$or_id = $_SESSION['or_id'];

$sql4 = "SELECT * FROM namewebsite";
$rs4 = mysqli_query($conn, $sql4);
$data4 = mysqli_fetch_array($rs4);


$sql3 = "SELECT order_detail.id, order_detail.productID, order_detail.unit_price, 
        order_detail.unittotal_price, orders.createdAt, order_detail.customerID, order_detail.orderID,
        order_detail.orderID, orders.total_price, orders.ship_price, orders.status, 
        customer.cus_name, customer.cus_phone, customer.cus_address, customer.cus_email
        FROM order_detail
            INNER JOIN orders ON (order_detail.orderID = orders.id) 
            INNER JOIN customer ON (order_detail.customerID = customer.id) 
            INNER JOIN product ON (order_detail.productID = product.id) 
        WHERE order_detail.orderID ='" . $_GET['id'] . "'";
$rs3 = mysqli_query($conn, $sql3);
$data3 = mysqli_fetch_array($rs3);
?>

<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $data4['nw_name']; ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 4 -->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body>
    <div class="wrapper">

        <!-- Main content -->
        <div class="invoice p-3 mb-3">
            <!-- title row -->
            <div class="row">
                <div class="col-12">
                    <h4>
                        <i class="fas fa-globe"></i> <?php echo $data4['nw_name']; ?>
                        <small class="float-right">Date/Time : <?php echo $data3['createdAt']; ?></small>
                    </h4>
                </div>
                <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    From
                    <address>
                        <strong><?php echo $data4['nw_name']; ?></strong><br>
                        <?php echo $data4['address']; ?><br>
                        Phone: <?php echo $data4['tel']; ?><br>
                        Email: <?php echo $data4['email']; ?>
                    </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                    To
                    <address>
                        <strong><?php echo $data3['cus_name']; ?></strong><br>
                        Address: <?php echo $data3['cus_address']; ?><br>
                        Phone: <?php echo $data3['cus_phone']; ?><br>
                        Email: <?php echo $data3['cus_email']; ?>
                    </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                    <b>Invoice #<?php echo $data3['orderID']; ?></b><br>
                    <b>Order ID: #<?php echo $data3['orderID']; ?></b><br>
                    <b>Payment Status:</b> <?php echo $data3['orderID']; ?><br>

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
                <div class="col-12 table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Product image</th>
                                <th>Product ID</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Amount</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>

                        <?php
                        $sql5 = "SELECT order_detail.productID, order_detail.unit_price, order_detail.unit,
                                                    order_detail.unittotal_price, product.name, product.product_id, product.price, product.photo
                                                    FROM order_detail
                                                        INNER JOIN orders ON (order_detail.orderID = orders.id) 
                                                        INNER JOIN customer ON (order_detail.customerID = customer.id) 
                                                        INNER JOIN product ON (order_detail.productID = product.id) 
                                                    WHERE order_detail.orderID ='$or_id'";
                        $rs5 = mysqli_query($conn, $sql5);
                        while ($data5 = mysqli_fetch_array($rs5)) {
                        ?>
                            <tbody>
                                <tr>
                                    <td><img src="<?= $data5['photo']; ?>" style="width: 3rem;"> </td>
                                    <td><?php echo $data5['product_id']; ?></td>
                                    <td><?php echo $data5['name']; ?></td>
                                    <td><?php echo $data5['price']; ?></td>
                                    <td><?php echo $data5['unit']; ?></td>
                                    <td><?php echo number_format($data5['unittotal_price'], 2); ?>.-</td>

                                </tr>

                            </tbody>

                        <?php } ?>

                    </table>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                    <!-- <p class="lead">Payment Methods:</p>
                    <img src="../bank_img/b1.png" style="width: 2rem;"> เลขบัญชี: 000-0-00000-0 ชื่อ: Lisa <br> -->
                </div>
                <!-- /.col -->
                <div class="col-6">
                    <p class="lead">Amount Due 2/22/2014</p>

                    <div class="table-responsive">
                        <table class="table">
                            <tr>
                                <?php
                                $ordersno_totalprice1 = $data3['total_price'];
                                $ordersno_shipping1 = $data3['ship_price'];
                                $total1 =  $ordersno_totalprice1 - $ordersno_shipping1;

                                ?>
                                <th style="width:50%">Subtotal:</th>
                                <td><?php echo number_format($total1, 2); ?>.- Baht</td>
                            </tr>
                            <tr>
                                <th>Shipping:</th>
                                <td><?php echo number_format($data3['ship_price'], 2); ?>.- Baht</td>
                            </tr>
                            <tr>
                                <th>Total:</th>
                                <?php
                                $ordersno_totalprice = $data3['total_price'];
                                $ordersno_shipping = $data3['ship_price'];
                                $total =  $ordersno_totalprice + $ordersno_shipping;

                                ?>
                                <td><?php echo number_format($total, 2); ?>.- Baht</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- ./wrapper -->

        <script type="text/javascript">
            window.addEventListener("load", window.print());
        </script>
</body>

</html>