<?php
session_start();
@error_reporting(E_ALL ^ E_NOTICE);
require_once("config/connect.config.php");
date_default_timezone_set('Asia/Bangkok');

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Soft Landing Page by Tooplate</title>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="team" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->

    <!-- fa -->
    <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@5.11.2/css/all.min.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/tooplate-style.css">

</head>

<body>
    <br><br><br><br>
    <div class="row">
        <div class="col-md-9 col-md-offset-2">
            <form method="post" action="" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Customer information</h3>
                        <hr>
                        <label for="mid">Name</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="name" id="name" value="<?php echo $_GET["name"]; ?>" class="form-control" style="width: 450px; height: 40px;">

                        <label for="midcard">Phone number that can be contacted</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="phone" id="phone" value="<?php echo $_GET["phone"]; ?>" required class="form-control" style="width: 450px; height: 40px;">

                        <label for="midcard">E-mail</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="email" id="email" value="<?php echo $_GET["email"]; ?>" required class="form-control" style="width: 450px; height: 40px;">

                        <label for="midcard">Address</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <textarea type="text" name="address" id="address" required class="form-control" style="width: 450px; height: 100px;"><?php echo $_GET["address"]; ?> </textarea>

                        <label for="midcard">Specify notes, if any ...</label>
                        <textarea type="address" name="note" id="note" class="form-control" style="width: 450px; height: 80px;"><?php echo $_GET["note"]; ?></textarea>
                        <br>
                    </div>

                    <div class="col-md-6">
                        <h3>Orders</h3>
                        <hr>

                        <table class="table table-striped">
                            <tr>
                                <th width="10"></th>
                                <th class="active">Name</th>
                                <th class="active">Quantity</th>
                                <th class="active">Unit</th>
                                <th class="active">Price</th>
                            </tr>

                            <?php
                            require_once("config/connect.config.php");
                            $total = 0;
                            foreach ($_SESSION['shopping_cart'] as $id => $qty) {
                                $sql = "SELECT * from product where id=$id";
                                $query = mysqli_query($conn, $sql);
                                $row    = mysqli_fetch_array($query);
                                $sum    = $row['price'] * $qty;
                                $total    += $sum;
                                echo "<tr>";
                                echo "<td>" . "<img src='$row[photo]' height='55rem' width='70rem' />" . "</td>";
                                echo "<td>" . $row["name"] . "</td>";
                                echo "<td>" . number_format($row['price']) . "</td>";
                                echo "<td> $qty </td>";
                                echo "<td>" . number_format($sum) . "</td>";
                                echo "</tr>";
                            }
                            ?>

                        </table>
                        <table class="table table-striped">
                            <tr>
                                <th width="100%">Total</th>
                                <td width="100%"><?= $total ?></td>
                            </tr>
                            <tr>
                                <th width="100%">Shipping</th>
                                <td width="100%"><?php echo $_GET["ship"]; ?></td>
                            </tr>
                            <tr>
                                <th width="100%">Net Total</th>
                                <td width="100%"><?= $nettotal = $total + $_GET["ship"]; ?></td>
                            </tr>
                        </table>
                        <hr>

                        <button type="submit" name="submit" id="btn" class="button"><span class="fa fa-cart-plus"></span> Buy →</button>
                        <br>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br> <br>

    <!-- SCRIPTS -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/custom.js"></script>

</body>


<?php
if (isset($_POST['submit'])) {

    $name = $_GET["name"];
    $phone = $_GET["phone"];
    $address = $_GET["address"];
    $email = $_GET["email"];
    $ship = $_GET["ship"];
    $note = $_GET["note"];

    $cus_query = "INSERT INTO customer (cus_name, cus_phone, cus_address, cus_email , createdAt, updatedAt)
						VALUES ('$name', '$phone', '$address', '$email', NOW(), NOW())";
    $cus_query1 = mysqli_query($conn, $cus_query) or die("Insert customer Failed");
    $customerID = mysqli_insert_id($conn);

    ///////////////////////////////////////////////////////

    $status = 1;

    for ($a == 1; $a < 1; $a++) {
        $number = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZqwertyuiopasdfghjklzxcvbnm';

        for ($i == 1; $i < 20; $i++) {
            $random = rand(0, strlen($number) - 1);
            $cut_txt = substr($number, $random, 1);
            $result .= substr($number, $random, 1);
            $number = str_replace($cut_txt, '', $number);
        }

        $i = 0;

        $sql_orders = "INSERT INTO orders (customerID, createdAt, updatedAt, total_price, status, ship_price,runnumber,note)
     					VALUES ('$customerID', NOW(), NOW(),'$nettotal',$status,'$ship','$result','$note')";
        $sql_orders1 = mysqli_query($conn, $sql_orders) or die("Insert order Failed");
        $orderID = mysqli_insert_id($conn);
    }



    ///////////////////////////////////////////////////////

    if (isset($_SESSION['shopping_cart'])) {
        foreach ($_SESSION['shopping_cart'] as $id => $qty) {

            $sql = "SELECT * from product where id=$id";
            $query = mysqli_query($conn, $sql);
            $row    = mysqli_fetch_array($query);

            $productID = $id;
            $unit_price = $row['price'];
            $unit = $qty;
            $unit_price_total = $row['price'] * $qty;

            $order_detail_query = "INSERT INTO order_detail (id, productID, unit_price, unit, unittotal_price, createdAt, updatedAt, customerID, orderID)
                                     VALUES ('','$productID','$unit_price','$unit','$unit_price_total',NOW(),NOW(),'$customerID','$orderID')";
            $order_detail_query1 = mysqli_query($conn, $order_detail_query) or die("Insert Orders Failed");

            ///////////////////////////////////////////////////
        }
    }
    mysqli_close($conn);
    if ($order_detail_query1) {
        unset($_SESSION['shopping_cart']);

        $_SESSION['c_id'] = $customerID;
        $_SESSION['or_id'] = $orderID;

        echo "<script>";
        echo "window.location='6_orders.php';";
        echo "alert('เพิ่มข้อมูลแล้ว');";
        echo "</script>";
    }
}

?>

</html>