<?php
date_default_timezone_set('Asia/Bangkok');
session_start();
@error_reporting(E_ALL ^ E_NOTICE);
require_once("config/connect.config.php");

$sqlorders = "SELECT * FROM orders 
                INNER JOIN customer 
                ON (orders.customerID = customer.id) 
                WHERE orders.id = '" . $_GET['id'] . "'";
$resultorders = mysqli_query($conn, $sqlorders);
$dataorders = mysqli_fetch_array($resultorders);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Soft Landing Page by Tooplate</title>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="team" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->

    <!-- fa -->
    <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@5.11.2/css/all.min.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/tooplate-style.css">

</head>

<body>
    <br><br><br><br>
    <center>
        <h2>Payment</h2>
    </center>

    <div class="row">
        <div class="col-md-9 col-md-offset-2">
            <form name="form1" method="post" action="" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 col-md-offset-2">
                        <hr>
                        <!-- <form name="form1" method="post" action="" enctype="multipart/form-data"> -->
                        <label for="mid">Order number</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="runnumber" id="runnumber" value="<?= $dataorders['runnumber']; ?>" class="form-control" style="width: 555px; height: 40px;"><br>


                        <label for="mid">Payment methods</label>
                        <label for="mpass" style="color:#F00">*</label>

                        <select id="bank" name="bank" class="form-control">
                            <?php
                            $sql5 = "SELECT * FROM bank";
                            $rs5 = mysqli_query($conn, $sql5);
                            while ($data5 = mysqli_fetch_array($rs5)) {
                            ?>
                                <option value="<?= $data5['id']; ?>"><?= $data5['namebank']; ?> ชื่อบัญชี: <?= $data5['name']; ?> เลขบัญชี: <?= $data5['account']; ?> promptpay: <?= $data5['promptpay']; ?></option>
                            <?php } ?>
                        </select>
                        <br>

                        <!-- <input type="radio" name="radios" id="radios-0" value="" checked="checked">
                        <img src="images/logo_scb.jpg" alt="..." class="img-rounded" width="40">
                        <label for="midcard">SCB เลขบัญชี xxx.xxxx.xxxxx.xx.x.x.xx บริษัท เอคโค่ เฮลท์ จํากัด</label>
                        <label for="midcard">Shipping</label><br><br> -->

                        <label for="mid">Payment date</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <div class="col-9">
                            <div class="input-group date" data-provide="datepicker" data-date-format="dd/mm/yyyy">
                                <input type="date" class="form-control" placeholder="เมือวันที่" maxlength="10" name="date">
                            </div>
                        </div><br>

                        <label for="mid">Payment time</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <div class="col-9">
                            <div class="col-sm-12">
                                <input class="form-control" placeholder="เวลาการโอน ตัวอย่าง 18:53" type="time" name="time">
                            </div>
                        </div><br>

                        <label for="mid">Amount of money</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="paytotal" value="<?= $paytotal = $dataorders['total_price'] + $dataorders['ship_price']; ?>" id="paytotal" class="form-control" style="width: 555px; height: 40px;">
                        <small class="form-text text-muted">ระบุจำนวนเงิน (฿)</small><br><br>

                        <label for="mid">credit</label><label for="mpass" style="color:#F00">*</label>
                        <input type="file" name="img" id="exampleInputFile" required>
                        <p class="help-block">ไฟล์ .jpg, .png</p>
                        <!--  </form> -->
                        <br><br>


                        <h4>Customer information</h4>
                        <hr>
                        <!-- <form name="form1" method="post" action="" enctype="multipart/form-data"> -->
                        <label for="mid">Name</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="name" id="name" class="form-control" style="width: 555px; height: 40px;" value="<?= $dataorders['cus_name']; ?>">

                        <label for="midcard">Phone number that can be contacted</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="phone" id="phone" required class="form-control" style="width: 555px; height: 40px;" value="<?= $dataorders['cus_phone']; ?>">

                        <label for="midcard">Address</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <textarea type="text" name="address" id="address" required class="form-control" style="width: 555px; height: 100px;"><?= $dataorders['cus_address']; ?></textarea>

                        <label for="midcard">Specify notes, if any ...</label>
                        <textarea type="text" name="note" id="note" required class="form-control" style="width: 555px; height: 100px;"><?= $dataorders['note']; ?></textarea>
                        <!-- </form> --><br>

                        <button type="submit" name="submit" id="btn" class="button"><span class="fa fa-cart-plus"></span> Buy →</button>

                        <!-- <button type="button" name="submit" id="submit" class="button">Confirmation →</button> -->
                        <!-- </form> -->
                    </div>
                </div>
            </form>
        </div>
    </div>

    <br> <br> <br> <br> <br> <br>

    <!-- SCRIPTS -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/custom.js"></script>

</body>

<?php
if (isset($_POST['submit'])) {

    $runnumber = $dataorders['runnumber'];
    $bank = $_GET["bank"];
    $date = $_GET["date"];
    $time = $_GET["time"];
    $credit = $paytotal;
    $note = $dataorders['note'];
    $orderID = $_GET['id'];
    $status = 2;
    /* 
    $cus_query = "INSERT INTO payment (id,  date, time, orderID , paytotal)
						VALUES ('$runnumber','$date','$time','$orderID','$paytotal')";
    $cus_query1 = mysqli_query($conn, $cus_query) or die("Insert customer Failed"); */

    $uploaddir = 'img/slip/';
    $uploadfile = $uploaddir . basename($_FILES['img']['name']);

    if (move_uploaded_file($_FILES['img']['tmp_name'], $uploadfile)) {

        $sl_img = "img/slip/" . $_FILES["img"]["name"];

        $cus_query = "INSERT INTO payment (id, paytotal, img, date1, time1, orderID , bankID, payment_statusID)
						VALUES ('$runnumber','$credit','$sl_img','$date','$time','$orderID','$bank','$status')";
        $cus_query1 = mysqli_query($conn, $cus_query) or die("Insert customer Failed");
    }

    ///////////////////////////////////////////////////////

    echo "<script>";
    echo "window.location='1_home.php';";
    echo "alert('เพิ่มข้อมูลแล้ว');";
    echo "</script>";
}
?>

</html>