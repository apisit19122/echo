<?php
session_start();
@error_reporting(E_ALL ^ E_NOTICE);
require_once("config/connect.config.php");
date_default_timezone_set('Asia/Bangkok');

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Soft Landing Page by Tooplate</title>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="team" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->

    <!-- fa -->
    <link rel="stylesheet" href="https://unpkg.com/@fortawesome/fontawesome-free@5.11.2/css/all.min.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/tooplate-style.css">

</head>

<body>
    <br><br><br><br>
    <div class="row">
        <div class="col-md-9 col-md-offset-2">
            <form method="get" action="5_checkout.php" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Customer information</h3>
                        <hr>
                        <!-- <form method="get" action="5_payment.php" enctype="multipart/form-data"> -->
                        <label for="mid">Name</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="name" id="name" required class="form-control" style="width: 450px; height: 40px;">

                        <label for="midcard">Phone number that can be contacted</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="phone" id="phone" required class="form-control" style="width: 450px; height: 40px;">

                        <label for="midcard">E-mail</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <input type="text" name="email" id="email" required class="form-control" style="width: 450px; height: 40px;">

                        <label for="midcard">Address</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <textarea type="text" name="address" id="address" required class="form-control" style="width: 450px; height: 100px;"></textarea>
                        <br>
                        <a href=""><button type="submit" name="submit" id="btn" class="button">Confirmation →</button></a>
                    </div>

                    <div class="col-md-6">
                        <h3>Orders</h3>
                        <hr>

                        <table class="table table-striped">
                            <tr>
                                <th width="10"></th>
                                <th class="active">Name</th>
                                <th class="active">Quantity</th>
                                <th class="active">Unit</th>
                                <th class="active">Price</th>
                            </tr>

                            <?php
                            require_once("config/connect.config.php");
                            $total = 0;
                            foreach ($_SESSION['shopping_cart'] as $id => $qty) {
                                $sql = "SELECT * from product where id=$id";
                                $query = mysqli_query($conn, $sql);
                                $row    = mysqli_fetch_array($query);
                                $sum    = $row['price'] * $qty;
                                $total    += $sum;
                                echo "<tr>";
                                echo "<td>" . "<img src='$row[photo]' height='55rem' width='70rem' />" . "</td>";
                                echo "<td>" . $row["name"] . "</td>";
                                echo "<td>" . number_format($row['price']) . "</td>";
                                echo "<td> $qty </td>";
                                echo "<td>" . number_format($sum) . "</td>";
                                echo "</tr>";
                            }
                            ?>

                        </table>
                        <table class="table table-striped">
                            <tr>
                                <th width="100%">Total</th>
                                <td width="100%"><?= $total ?></td>
                            </tr>
                        </table>

                        <label for="midcard">Shipping</label>
                        <label for="mpass" style="color:#F00">*</label>
                        <select id="ship" name="ship" class="form-control" style="width: 560; height: 40px;">
                            <?php
                            $ship = "SELECT * FROM shippingcost";
                            $query_ship = mysqli_query($conn, $ship);
                            while ($data_ship = mysqli_fetch_array($query_ship, MYSQLI_ASSOC)) {
                            ?>
                                <option value="<?= $data_ship['cost']; ?>"><?= $data_ship['type']; ?> <?= $data_ship['cost']; ?> บาท</option>
                            <?php
                            } ?>
                        </select><br>

                        <label for="midcard">Specify notes, if any ...</label>
                        <textarea type="text" name="note" id="note" class="form-control" style="width: 560; height: 80px;"></textarea> <br>

                    </div>
                </div>
            </form>
        </div>
    </div>
    <br> <br> <br> <br> <br> <br>

    <!-- SCRIPTS -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/custom.js"></script>

</body>


<!-- <?php

        if (isset($_POST['submit'])) {
            require_once("config/connect.config.php");
            $name = $_POST['name'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            $email = $_POST['email'];

            $sql2 = "insert into customer (name, phone, address, email , createdAt, updatedAt) 
    values('$name', '$phone', '$address', '$email', NOW(), NOW())";
            mysqli_query($conn, $sql2) or die("insert ไม่ได้");

            if ($num > 0) {
                $_SESSION['name'] = $data['name'];
                $_SESSION['address'] = $data['address'];
                $_SESSION['email'] = $data['email'];
                $_SESSION['phone'] = $data['phone'];
                echo "<script>";
                echo "window.location='5_payment.php';";
                echo "alert('เพิ่มข้อมูลแล้ว');";
                echo "</script>";
            }
        }

        ?> -->

</html>